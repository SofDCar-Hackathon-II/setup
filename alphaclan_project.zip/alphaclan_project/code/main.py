import os
from kuksa_client.grpc import VSSClient
from kuksa_client.grpc import Datapoint
from landingai.pipeline.image_source import Webcam
from gesture import GestureDetector
import cv2
from auto_trunk_opener import open_trunk


# Define a function to set the value of a VSS signal
def set_vss_value(vss, value):
    client.set_current_values({
        vss: Datapoint(value)
    })
ges_detector = GestureDetector(max_num_hands=1)

# Connect to the KUKSA server
with VSSClient('192.168.1.99', 55556) as client:

    # Start the webcam
    with Webcam(fps=0.25) as webcam:

        for frame in webcam:
            
            frame.save_image("./latest-webcam-image.png")

            trunk_open = open_trunk("./latest-webcam-image.png")
            ges_detector.detect_gesture(cv2.imread("./latest-webcam-image.png"), 'single')

            if trunk_open:
                print(trunk_open)
                set_vss_value("Vehicle.Door.Row1.DriverSide.Action", "open")
            
            if ges_detector.detected_gesture == "One":
                print(ges_detector.detected_gesture)
                set_vss_value("Vehicle.Door.Row1.DriverSide.Action", "close")
            
            elif ges_detector.detected_gesture == "Two (Yeah)":
                print(ges_detector.detected_gesture)
                set_vss_value("Vehicle.Door.Row1.DriverSide.Action", "close")
                set_vss_value("Vehicle.Door.Row2.DriverSide.Action", "close")

            elif ges_detector.detected_gesture == "Five":
                pass

            # Similarly, other gestures can be customized.

            image = cv2.imread("./latest-webcam-image.png")
            cv2.imshow('image', image)

            if cv2.waitKey(25) & 0xFF == ord('q'):
               break