import torch
import clip
from PIL import Image
import torchvision.transforms as T
import numpy as np


def open_trunk(image_path):
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model, preprocess = clip.load("ViT-B/32", device=device)
    image = preprocess(Image.open(image_path)).unsqueeze(0).to(device)
    text = clip.tokenize(["shopping", "not shopping"]).to(device)

    with torch.no_grad():
        #image_features = model.encode_image(image)
        #text_features = model.encode_text(text)
        logits_per_image, logits_per_text = model(image, text)
        probs = logits_per_image.softmax(dim=-1).cpu().numpy()

    #print(probs)
    if np.argmax(probs[0]) == 0 and probs[0][np.argmax(probs[0])] > 0.65:
        # print("Open the Trunk!!!")
        return True
    else:
        #print("Don't open the trunk")
        return False


#image_path = "img.png"
#print(open_trunk(image_path))