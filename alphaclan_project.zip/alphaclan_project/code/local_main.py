import cv2 as cv
import matplotlib.pyplot as plt

# from gesture_recognition_cv import count_fingers
from gesture import GestureDetector
from auto_trunk_opener import open_trunk


cap = cv.VideoCapture(0) # '0' for webcam
ges_detector = GestureDetector(max_num_hands=1)

while True:
    _, img = cap.read()
    try:
        cv.imwrite("img.png", img)
        ges_detector.detect_gesture(img, 'single')
        trunk_open = open_trunk("img.png")
        if ges_detector.detected_gesture is not None:
            print("Recognized ", ges_detector.detected_gesture, "finger(s) gesture.")
        if trunk_open:
            print("Shopping Object detected!")
        
    except:
        pass

    if cv.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv.destroyAllWindows()
